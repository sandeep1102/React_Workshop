import React from 'react'

function SamplePropsFunc(props) {
  return (
    <div>Welcome {props.name}, {props.age}</div>
  )
}

export default SamplePropsFunc